common components

## License

Apache-2.0. See [LICENSE](LICENSE).

The `license` field in `package.json` and the `LICENSE` file were added after
1.1.20 was published. Neither existed before that — including in 1.1.20 itself,
which is still the version the registry serves as `latest` — so the published
artifact stated no terms at all and npm labelled the package `Proprietary`,
its display for "no grant stated". That is not a restriction anyone chose; it is
a field nobody filled in, and it left every consumer of this package without an
answer to "under what terms?". The next published version carries the answer.

1.1.21 is skipped rather than used. A `v1.1.21` tag exists on the remote, but it
points at a commit whose `package.json` still said `1.1.19`, so the publish
workflow's tag-equals-version check rejects it and nothing was ever released
under that number — `npm view @gpustack/core-ui@1.1.21` returns 404. Reusing the
number would mean moving a pushed tag; the next version is cheaper and honest.

Two things about that file are deliberately explicit, because both are easy to
forget:

* The copyright line names **OriginHub authors** as a placeholder for a legal
  entity. Replace it with the entity that actually holds the copyright before this
  licence is relied on in a contract or a due-diligence response.
* Declaring Apache-2.0 is a statement that the copyright holder is entitled to
  grant those terms for everything in this repository. If any source here was
  extracted from a distribution that is not open source, that statement is wrong
  and this licence must not be published until that code is removed or the
  licence is changed. The declaration in `package.json` is not verified by any
  automated check in this repository — it is a statement, and statements are only
  as good as the review behind them.

npm includes `LICENSE` and `README` in the published tarball regardless of the
`files` allow-list, so `"files": ["dist"]` does not keep the licence out.
